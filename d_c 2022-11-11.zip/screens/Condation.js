import React from "react";
import {Text, View,Button} from "react-native";
const Condation =({ navigation })=>{
    return(
   
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
                <Text>
            This is the condation screen.
            </Text>
            <Button
              onPress={() => navigation.navigate('Home')}
              title="Go to Home"
            />
          </View>
    )
}

export default Condation;