import React from "react";
import {Text, View,Button,TouchableOpacity,ScrollView} from "react-native";
import { createDrawerNavigator } from '@react-navigation/drawer';
import { NavigationContainer } from '@react-navigation/native';
import Ionicons from '@expo/vector-icons/Ionicons';
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import Styles from "../components/Styles";
const TV =({ navigation })=>{
    return(
<ScrollView>
   <View style={Styles.mainContainer}>
        <View style={Styles.remoteContainer}>
             <View style={Styles.row}>
                <TouchableOpacity style={{...Styles.btn,backgroundColor:"red"}}><Text style={Styles.btnText}><Ionicons name="power" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}> <Ionicons name="md-volume-mute-sharp" size={34} color="wite" /> </Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="log-in" size={34} color="white" /></Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>1</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>2</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>3</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>4</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>5</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>6</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>7</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>8</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>9</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="volume-medium" size={34} color="white" />-</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>0</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="volume-medium" size={34} color="white" />+</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="home" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="chevron-up-sharp" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="logo-youtube" size={40} color="red" /></Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><AntDesign name="left" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>OK</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><AntDesign name="right" size={34} color="white" /></Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="menu" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><AntDesign name="down" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}><Ionicons name="arrow-redo-sharp" size={34} color="white" /></Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={{...Styles.btn,backgroundColor:'red',width:"20%"}}><Text style={Styles.btnText}>A</Text></TouchableOpacity>
                <TouchableOpacity style={{...Styles.btn,backgroundColor:'green',width:"20%"}}><Text style={Styles.btnText}>B</Text></TouchableOpacity>
                <TouchableOpacity style={{...Styles.btn,backgroundColor:'yellow',width:"20%"}}><Text style={Styles.btnText}>C</Text></TouchableOpacity>
                <TouchableOpacity style={{...Styles.btn,backgroundColor:'blue',width:"20%"}}><Text style={Styles.btnText}>D</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>«</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>▶</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn}><Text style={Styles.btnText}>»</Text></TouchableOpacity>
             </View>
             <View style={Styles.row}>
                <TouchableOpacity style={Styles.btn2} onPress={() => navigation.navigate('RGB')}><Text style={Styles.btnText}>RGB</Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn2} onPress={() => navigation.navigate('Conditioner')}><Text style={Styles.btnText}><FontAwesome5 name="fan" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn2} onPress={() => navigation.navigate('Home')}><Text style={Styles.btnText}><Ionicons name="home" size={34} color="white" /></Text></TouchableOpacity>
                <TouchableOpacity style={Styles.btn2}><Text style={Styles.btnText}></Text></TouchableOpacity>
             </View>
        </View></View></ScrollView>
    )
}

export default TV;